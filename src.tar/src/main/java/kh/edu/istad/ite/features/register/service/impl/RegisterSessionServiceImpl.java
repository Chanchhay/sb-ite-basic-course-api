package kh.edu.istad.ite.features.register.service.impl;

import kh.edu.istad.ite.config.props.KeycloakAdminClientProps;
import kh.edu.istad.ite.features.business.entity.Business;
import kh.edu.istad.ite.features.business.repository.BusinessRepository;
import kh.edu.istad.ite.features.order.repository.OrderRepository;
import kh.edu.istad.ite.features.register.dto.request.CashMovementRequest;
import kh.edu.istad.ite.features.register.dto.request.CloseSessionRequest;
import kh.edu.istad.ite.features.register.dto.request.OpenSessionRequest;
import kh.edu.istad.ite.features.register.dto.response.CashMovementResponse;
import kh.edu.istad.ite.features.register.dto.response.RegisterSessionResponse;
import kh.edu.istad.ite.features.register.entity.*;
import kh.edu.istad.ite.features.register.repository.CashMovementRepository;
import kh.edu.istad.ite.features.register.repository.CashRegisterRepository;
import kh.edu.istad.ite.features.register.repository.RegisterSessionRepository;
import kh.edu.istad.ite.features.register.service.RegisterSessionService;
import kh.edu.istad.ite.features.user.entity.UserProfile;
import kh.edu.istad.ite.features.user.repository.UserProfileRepository;
import kh.edu.istad.ite.shared.enums.CashMovementType;
import kh.edu.istad.ite.shared.enums.RegisterStatus;
import kh.edu.istad.ite.shared.enums.SessionStatus;
import kh.edu.istad.ite.shared.exception.AppGlobalException;
import lombok.RequiredArgsConstructor;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RegisterSessionServiceImpl implements RegisterSessionService {

    private final CashRegisterRepository registerRepository;
    private final RegisterSessionRepository sessionRepository;
    private final CashMovementRepository movementRepository;
    private final UserProfileRepository userProfileRepository;
    private final BusinessRepository businessRepository;
    private final OrderRepository orderRepository;
    private final kh.edu.istad.ite.features.order.repository.SaleRepository saleRepository;
    private final Keycloak keycloak;
    private final KeycloakAdminClientProps props;

    @Override
    @Transactional
    public RegisterSessionResponse openSession(OpenSessionRequest request, String userId) {
        UUID userUuid = UUID.fromString(userId);
        Business business = businessRepository.findByKeycloakUserId(userUuid).orElse(null);

        if (business == null) {
            UserProfile profile = userProfileRepository.findById(userUuid)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User profile not found"));
            business = profile.getBusiness();
        }

        if (business == null) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "User is not associated with any business");
        }
        
        UUID businessId = business.getId();

        CashRegister register = registerRepository.findByBusinessId(businessId)
                .orElseGet(() -> {
                    CashRegister newRegister = CashRegister.builder()
                            .name("Main Register")
                            .businessId(businessId)
                            .status(RegisterStatus.CLOSED)
                            .build();
                    return registerRepository.save(newRegister);
                });

        if (register.getStatus() == RegisterStatus.OPEN) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cash register is already open");
        }

        RegisterSession existingSession = sessionRepository.findByRegisterIdAndStatus(register.getId(), SessionStatus.OPEN).orElse(null);
        if (existingSession != null) {
            return joinSession(existingSession.getId(), userId);
        }

        sessionRepository.findByUserIdAndStatus(userId, SessionStatus.OPEN).ifPresent(s -> {
            throw new ResponseStatusException( HttpStatus.BAD_REQUEST, "Cashier already has an active open session");
        });

        register.setStatus(RegisterStatus.OPEN);
        registerRepository.save(register);

        RegisterSession session = RegisterSession.builder()
                .register(register)
                .userId(userId)
                .businessId(businessId)
                .openedAt(Instant.now())
                // Fixed now: the drawer holds physical notes, so a later
                // base-currency change must not restate this session.
                .currency(businessRepository.findById(businessId)
                        .map(kh.edu.istad.ite.features.business.entity.Business::getBaseCurrency)
                        .orElse(null))
                .openingBalance(request.getOpeningBalance())
                .status(SessionStatus.OPEN)
                .note(request.getNote())
                .participants(new java.util.HashSet<>(java.util.Collections.singletonList(userId)))
                .build();

        session = sessionRepository.save(session);
        return mapToResponse(session, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    @Override
    @Transactional
    public RegisterSessionResponse closeSession(Long sessionId, CloseSessionRequest request) {
        RegisterSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Register session not found"));

        if (session.getStatus() == SessionStatus.CLOSED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Session is already closed");
        }

        LocalDateTime openedAt = LocalDateTime.ofInstant(session.getOpenedAt(), ZoneId.systemDefault());
        BigDecimal totalCashSales = saleRepository.sumCashSalesByCashierAndDateRange(session.getUserId(), openedAt, LocalDateTime.now());
        BigDecimal totalPaidIn = movementRepository.sumAmountBySessionIdAndType(sessionId, CashMovementType.PAID_IN);
        BigDecimal totalPaidOut = movementRepository.sumAmountBySessionIdAndType(sessionId, CashMovementType.PAID_OUT);

        BigDecimal expected = session.getOpeningBalance()
                .add(totalCashSales)
                .add(totalPaidIn)
                .subtract(totalPaidOut);

        BigDecimal actual = request.getActualAmount();
        BigDecimal difference = actual.subtract(expected);

        session.setClosedAt(Instant.now());
        session.setExpectedAmount(expected);
        session.setActualAmount(actual);
        session.setDifferenceAmount(difference);
        session.setStatus(SessionStatus.CLOSED);
        if (request.getClosingNote() != null) {
            session.setNote(session.getNote() != null ? session.getNote() + " | " + request.getClosingNote() : request.getClosingNote());
        }

        CashRegister register = session.getRegister();
        register.setStatus(RegisterStatus.CLOSED);
        registerRepository.save(register);

        sessionRepository.save(session);

        return mapToResponse(session, totalCashSales, totalPaidIn, totalPaidOut);
    }

    @Override
    @Transactional(readOnly = true)
    public RegisterSessionResponse getCurrentSession(String userId) {
        UUID userUuid = UUID.fromString(userId);
        Business business = businessRepository.findByKeycloakUserId(userUuid).orElse(null);

        if (business == null) {
            UserProfile profile = userProfileRepository.findById(userUuid).orElse(null);
            if (profile != null) {
                business = profile.getBusiness();
            }
        }

        if (business == null) {
            return null;
        }

        CashRegister register = registerRepository.findByBusinessId(business.getId()).orElse(null);
        if (register == null) {
            return null;
        }

        RegisterSession session = sessionRepository.findByRegisterIdAndStatus(register.getId(), SessionStatus.OPEN).orElse(null);
        if (session == null) {
            return null;
        }

        return getSessionSummary(session.getId());
    }

    @Override
    @Transactional
    public RegisterSessionResponse joinSession(Long sessionId, String userId) {
        RegisterSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Register session not found"));
        
        UUID userUuid = UUID.fromString(userId);
        Business business = businessRepository.findByKeycloakUserId(userUuid).orElse(null);
        if (business == null) {
            UserProfile profile = userProfileRepository.findById(userUuid).orElse(null);
            if (profile != null) {
                business = profile.getBusiness();
            }
        }
        
        if (business == null || !business.getId().equals(session.getBusinessId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Session does not belong to user's business");
        }

        if (session.getStatus() != SessionStatus.OPEN) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Session is not open");
        }

        session.getParticipants().add(userId);
        session = sessionRepository.save(session);
        
        return getSessionSummary(session.getId());
    }

    @Override
    @Transactional(readOnly = true)
    public RegisterSessionResponse getSessionSummary(Long sessionId) {
        RegisterSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Register session not found"));

        LocalDateTime openedAt = LocalDateTime.ofInstant(session.getOpenedAt(), ZoneId.systemDefault());
        LocalDateTime closedAt = session.getClosedAt() != null ? LocalDateTime.ofInstant(session.getClosedAt(), ZoneId.systemDefault()) : LocalDateTime.now();
        BigDecimal totalCashSales = saleRepository.sumCashSalesByCashierAndDateRange(session.getUserId(), openedAt, closedAt);
        BigDecimal totalPaidIn = movementRepository.sumAmountBySessionIdAndType(sessionId, CashMovementType.PAID_IN);
        BigDecimal totalPaidOut = movementRepository.sumAmountBySessionIdAndType(sessionId, CashMovementType.PAID_OUT);

        return mapToResponse(session, totalCashSales, totalPaidIn, totalPaidOut);
    }

    @Override
    @Transactional
    public CashMovementResponse addCashMovement(Long sessionId, CashMovementRequest request) {
        RegisterSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Register session not found"));

        if (session.getStatus() == SessionStatus.CLOSED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cannot add cash movement to a closed session");
        }

        CashMovement movement = CashMovement.builder()
                .session(session)
                .type(request.getType())
                .amount(request.getAmount())
                .reason(request.getReason())
                .build();

        movement = movementRepository.save(movement);

        return CashMovementResponse.builder()
                .id(movement.getId())
                .sessionId(sessionId)
                .currency(session.getCurrency())
                .type(movement.getType())
                .amount(movement.getAmount())
                .reason(movement.getReason())
                .createdAt(movement.getCreatedDate())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CashMovementResponse> getCashMovements(Long sessionId) {
        return movementRepository.findBySessionId(sessionId).stream()
                .map(m -> CashMovementResponse.builder()
                        .currency(m.getSession() == null ? null : m.getSession().getCurrency())
                        .id(m.getId())
                        .sessionId(sessionId)
                        .type(m.getType())
                        .amount(m.getAmount())
                        .reason(m.getReason())
                        .createdAt(m.getCreatedDate())
                        .build())
                .collect(Collectors.toList());
    }

    private RegisterSessionResponse mapToResponse(RegisterSession session, BigDecimal totalCashSales, BigDecimal totalPaidIn, BigDecimal totalPaidOut) {
        BigDecimal expected = session.getExpectedAmount() != null ? session.getExpectedAmount() :
                session.getOpeningBalance().add(totalCashSales).add(totalPaidIn).subtract(totalPaidOut);

        BigDecimal diff = session.getDifferenceAmount();
        String reconStatus = "MATCHED";
        if (diff != null) {
            if (diff.compareTo(BigDecimal.ZERO) > 0) reconStatus = "OVER";
            else if (diff.compareTo(BigDecimal.ZERO) < 0) reconStatus = "SHORT";
        }

        int orderCount = 0;
        if (session.getUserId() != null) {
            LocalDateTime start = LocalDateTime.ofInstant(session.getOpenedAt(), ZoneId.systemDefault());
            LocalDateTime end = session.getClosedAt() != null 
                    ? LocalDateTime.ofInstant(session.getClosedAt(), ZoneId.systemDefault()) 
                    : LocalDateTime.now();
            orderCount = (int) orderRepository.countByCashierIdAndCreatedDateBetween(UUID.fromString(session.getUserId()), start, end);
        }

        String cashierName = null;
        if (session.getUserId() != null) {
            try {
                UserResource userResource = keycloak.realm(props.getTargetRealm())
                        .users()
                        .get(session.getUserId());
                UserRepresentation keycloakUser = userResource.toRepresentation();
                cashierName = (keycloakUser.getFirstName() != null ? keycloakUser.getFirstName() : "") + 
                              (keycloakUser.getLastName() != null ? " " + keycloakUser.getLastName() : "");
                cashierName = cashierName.trim();
                if (cashierName.isEmpty()) {
                    cashierName = keycloakUser.getUsername();
                }
            } catch (Exception e) {
                cashierName = "Unknown";
            }
        }

        return RegisterSessionResponse.builder()
                .id(session.getId())
                .registerId(session.getRegister().getId())
                .registerName(session.getRegister().getName())
                .userId(session.getUserId())
                .cashierName(cashierName)
                .businessId(session.getBusinessId())
                .orderCount(orderCount)
                .openedAt(session.getOpenedAt())
                .closedAt(session.getClosedAt())
                .currency(session.getCurrency())
                .openingBalance(session.getOpeningBalance())
                .totalCashSales(totalCashSales)
                .totalPaidIn(totalPaidIn)
                .totalPaidOut(totalPaidOut)
                .expectedAmount(expected)
                .actualAmount(session.getActualAmount())
                .differenceAmount(diff)
                .reconciliationStatus(reconStatus)
                .status(session.getStatus())
                .note(session.getNote())
                .build();
    }
}
