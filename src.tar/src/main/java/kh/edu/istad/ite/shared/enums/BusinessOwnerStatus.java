package kh.edu.istad.ite.shared.enums;

public enum BusinessOwnerStatus {
    ACTIVE,
    SUSPENDED,
    DELETED
}
