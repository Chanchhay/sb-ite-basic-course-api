package kh.edu.istad.ite.features.social.service;

import kh.edu.istad.ite.config.security.CredentialCipher;
import kh.edu.istad.ite.features.customer.repository.CustomerChannelIdentityRepository;
import kh.edu.istad.ite.features.order.entity.Order;
import kh.edu.istad.ite.features.payment.entity.PaymentQrCode;
import kh.edu.istad.ite.features.payment.repository.PaymentQrCodeRepository;
import kh.edu.istad.ite.features.social.entity.BusinessTelegramBot;
import kh.edu.istad.ite.features.social.repository.BusinessTelegramBotRepository;
import kh.edu.istad.ite.features.social.event.TelegramQrGeneratedEvent;
import kh.edu.istad.ite.features.social.telegram.InlineKeyboardButton;
import kh.edu.istad.ite.features.social.telegram.TelegramBotClient;
import kh.edu.istad.ite.shared.enums.ChannelType;
import kh.edu.istad.ite.shared.enums.OrderChannel;
import kh.edu.istad.ite.shared.enums.OrderStatus;
import kh.edu.istad.ite.shared.enums.QrStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;


@Component
@Slf4j
@RequiredArgsConstructor
public class TelegramPaymentPoller {

    private final PaymentQrCodeRepository paymentQrCodeRepository;
    private final BusinessTelegramBotRepository telegramBotRepository;
    private final CustomerChannelIdentityRepository customerChannelIdentityRepository;
    private final TelegramCheckoutService telegramCheckoutService;
    private final TelegramBotClient telegramBotClient;
    private final CredentialCipher credentialCipher;
    private final TelegramAlertService telegramAlertService;

    private final AtomicBoolean hasPendingQr = new AtomicBoolean(false);

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        try {
            List<PaymentQrCode> outstanding = paymentQrCodeRepository.findOutstandingByChannel(
                    QrStatus.PENDING, OrderStatus.PENDING, OrderChannel.TELEGRAM);
            if (!outstanding.isEmpty()) {
                hasPendingQr.set(true);
                log.info("Startup check found {} outstanding Telegram payment(s), active polling enabled", outstanding.size());
            }
        } catch (Exception exception) {
            log.warn("Could not check outstanding Telegram QR codes on startup: {}", exception.getMessage());
        }
    }

    @EventListener
    public void onTelegramQrGenerated(TelegramQrGeneratedEvent event) {
        if (!hasPendingQr.getAndSet(true)) {
            log.info("Telegram QR code generated: enabling payment polling");
        }
    }

    @Scheduled(
            initialDelayString = "${app.telegram.payment-poll-initial-delay-ms:10000}",
            fixedDelayString = "${app.telegram.payment-poll-interval-ms:5000}")
    public void pollOutstandingPayments() {
        if (!hasPendingQr.get()) {
            return;
        }

        List<PaymentQrCode> outstanding;

        try {
            outstanding = paymentQrCodeRepository.findOutstandingByChannel(
                    QrStatus.PENDING, OrderStatus.PENDING, OrderChannel.TELEGRAM);
        } catch (Exception exception) {
            log.error("Could not load outstanding Telegram QR codes: {}", exception.getMessage());
            return;
        }

        if (outstanding.isEmpty()) {
            if (hasPendingQr.compareAndSet(true, false)) {
                log.info("No outstanding Telegram QR codes remaining: pausing payment polling");
            }
            return;
        }

        log.debug("Polling Bakong for {} outstanding Telegram payment(s)", outstanding.size());

        for (PaymentQrCode qrCode : outstanding) {
            try {
                process(qrCode);
            } catch (Exception exception) {
                log.warn("Polling failed for QR {}: {}", qrCode.getId(), exception.getMessage());
            }
        }
    }

    private void process(PaymentQrCode qrCode) {
        Order order = qrCode.getOrder();
        UUID businessId = qrCode.getBusiness().getId();

        TelegramCheckoutService.VerifyResult result;
        try {

            result = telegramCheckoutService.verifyAndSettle(businessId, order.getId());
        } catch (TelegramCheckoutException exception) {
            log.debug("Cannot verify Telegram order {} yet: {}", order.getId(), exception.getMessage());
            return;
        }

        if (result.paid()) {
            notifyPaid(businessId, order, result.invoiceNumber(), result.receiptText(), qrCode.getTelegramMessageId());
        } else if (result.expired()) {
            notifyExpired(businessId, order, qrCode.getTelegramMessageId());
        }
    }

    private void notifyPaid(UUID businessId, Order order, String invoiceNumber, String receiptText, Integer qrMessageId) {
        send(businessId, order,
                "🎉 *ការទូទាត់ជោគជ័យ!*\n"
                        + "━━━━━━━━━━━━━━━━━━━━\n"
                        + "🧾 លេខវិក្កយបត្រ ៖ `" + invoiceNumber + "`\n"
                        + "✅ ប្រព័ន្ធបានទទួលប្រាក់របស់អ្នករួចរាល់។\n\n"
                        + "អរគុណសម្រាប់ការបញ្ជាទិញ! ហាងកំពុងរៀបចំទំនិញជូនអ្នក។",
                List.of(List.of(new InlineKeyboardButton("🛍️ ទិញទំនិញបន្ត", "menu:catalog")),
                        List.of(new InlineKeyboardButton("⬅️ ម៉ឺនុយដើម", "menu:main"))), qrMessageId);

        // The actual receipt, as its own message so it stays easy to screenshot/forward.
        if (receiptText != null) {
            send(businessId, order, receiptText, null, null);
        }

        log.info("Auto-confirmed Telegram order {} ({})", order.getId(), invoiceNumber);
        
        // Alert the business owner
        telegramAlertService.sendQrPaymentAlert(order);
    }

    private void notifyExpired(UUID businessId, Order order, Integer qrMessageId) {
        send(businessId, order,
                "⏰ *កូដ KHQR បានផុតកំណត់*\n"
                        + "━━━━━━━━━━━━━━━━━━━━\n"
                        + "🧾 លេខវិក្កយបត្រ ៖ `" + order.getInvoiceNumber() + "`\n\n"
                        + "ទំនិញនៅតែរក្សាទុកក្នុងកន្ត្រករបស់អ្នក។ សូមចុច គិតលុយ ដើម្បីបង្កើតកូដថ្មី។",
                List.of(List.of(new InlineKeyboardButton("🛒 មើលកន្ត្រក", "menu:cart")),
                        List.of(new InlineKeyboardButton("⬅️ ម៉ឺនុយដើម", "menu:main"))), qrMessageId);
    }

    private void send(UUID businessId, Order order, String message,
                      List<List<InlineKeyboardButton>> keyboard, Integer messageIdToDelete) {
        if (order.getCustomer() == null) {
            return;
        }

        Optional<BusinessTelegramBot> botSetting = telegramBotRepository.findByBusiness_Id(businessId);

        if (botSetting.isEmpty() || !Boolean.TRUE.equals(botSetting.get().getIsActive())) {
            log.debug("No active Telegram bot for business {}, skipping notification", businessId);
            return;
        }

        Optional<String> chatId = customerChannelIdentityRepository
                .findByBusiness_IdAndChannelAndCustomer_Id(
                        businessId, ChannelType.TELEGRAM, order.getCustomer().getId())
                .map(identity -> identity.getExternalId());

        if (chatId.isEmpty()) {
            log.warn("No Telegram identity for customer {} in business {}, cannot notify",
                    order.getCustomer().getId(), businessId);
            return;
        }

        try {
            String botToken = credentialCipher.decrypt(botSetting.get().getBotTokenEncrypted());
            
            if (messageIdToDelete != null) {
                telegramBotClient.deleteMessageAsync(botToken, Long.parseLong(chatId.get()), messageIdToDelete);
            }
            
            telegramBotClient.sendMessage(botToken, Long.parseLong(chatId.get()), message, keyboard);
        } catch (NumberFormatException exception) {
            log.warn("Telegram external id {} is not a numeric chat id", chatId.get());
        } catch (Exception exception) {
            log.warn("Could not deliver the Telegram notification: {}", exception.getMessage());
        }
    }
}